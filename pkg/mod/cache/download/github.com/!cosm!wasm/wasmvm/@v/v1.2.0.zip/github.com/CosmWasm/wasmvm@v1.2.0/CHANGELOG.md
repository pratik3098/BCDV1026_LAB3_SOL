# CHANGELOG

No CHANGELOG is maintained here. Yeah, that's bad but time is limited and people
want new features quickly. Maintenance is not appreciated much in the ecosystem.
It's a shame, I know. We should change that.

You find a few incomplete notes in the
[GitHub releases](https://github.com/CosmWasm/wasmvm/releases).
