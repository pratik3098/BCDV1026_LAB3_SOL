//go:build sys_wasmvm

package api

// #cgo LDFLAGS: -lwasmvm
import "C"
