---
order: false
parent:
  title: Introduction
  order: 1
---

# Overview

## Quick Start

Get Tendermint up-and-running quickly with the [quick-start guide](./quick-start.md)!

## Install

Detailed [installation instructions](./install.md).

## What is Tendermint

Dive into [what Tendermint is and why](./what-is-tendermint.md)!
