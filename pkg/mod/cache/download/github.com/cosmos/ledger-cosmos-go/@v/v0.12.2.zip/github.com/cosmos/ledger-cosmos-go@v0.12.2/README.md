# ledger-cosmos-go

[![Test](https://github.com/cosmos/ledger-cosmos-go/actions/workflows/test.yml/badge.svg)](https://github.com/cosmos/ledger-cosmos-go/actions/workflows/test.yml)
[![Build status](https://ci.appveyor.com/api/projects/status/ovpfx35t289n3403?svg=true)](https://ci.appveyor.com/project/cosmos/ledger-cosmos-go)

This project is work in progress. Some aspects are subject to change.

# Get source
Apart from cloning, be sure you install dep dependency management tool
https://github.com/golang/dep
