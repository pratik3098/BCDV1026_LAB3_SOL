package test

type ProtoTypesPointer []*ProtoType
type ProtoTypesNotPointer []ProtoType
