package types

const (
	ModuleName = "intertx"

	StoreKey = ModuleName

	RouterKey = ModuleName

	QuerierRoute = ModuleName
)
