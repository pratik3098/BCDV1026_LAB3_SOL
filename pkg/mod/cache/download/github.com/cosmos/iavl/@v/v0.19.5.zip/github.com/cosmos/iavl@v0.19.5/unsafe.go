package iavl

import ibytes "github.com/cosmos/iavl/internal/bytes"

var (
	unsafeToStr = ibytes.UnsafeBytesToStr
	unsafeToBz  = ibytes.UnsafeStrToBytes
)
