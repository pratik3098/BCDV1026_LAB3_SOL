// Package ECDSA implements Cosmos-SDK compatible ECDSA public and private key. The keys
// can be serialized.
package ecdsa
