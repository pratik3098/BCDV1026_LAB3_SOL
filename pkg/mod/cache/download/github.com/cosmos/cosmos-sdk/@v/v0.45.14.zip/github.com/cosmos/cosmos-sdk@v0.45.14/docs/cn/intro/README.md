# 介绍

此目录包含对 cosmos sdk 的相关介绍

1. [概述](./overview.md)

2. [基于特定应用的区块链](./why-app-specific.md)

3. [应用架构](./sdk-app-architecture.md)

4. [Cosmos SDK 设计概述](./sdk-design.md)

了解完成相关介绍后，可以前往 [基础文档](../basics/README.md) 了解更多。
