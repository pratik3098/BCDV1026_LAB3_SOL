/*
Package timepb provides functions to do time operations with protobuf timestamp
and duration structures.
*/
package timepb
