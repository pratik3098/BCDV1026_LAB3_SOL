# copied
this pkg contains code copied from google's protobuf-gen-go implementation
