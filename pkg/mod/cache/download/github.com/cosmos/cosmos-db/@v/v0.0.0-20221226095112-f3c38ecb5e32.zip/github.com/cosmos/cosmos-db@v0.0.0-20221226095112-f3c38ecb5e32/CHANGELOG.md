# Changelog

## Unreleased

- added bloom filter:  https://github.com/cosmos/cosmos-db/pull/42/files
- Removed Badger & Boltdb
- Add `NewBatchWithSize` to `DB` interface: https://github.com/cosmos/cosmos-db/pull/64