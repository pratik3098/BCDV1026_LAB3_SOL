<!--
order: 2
-->

# State

The solo machine light client will only store consensus states for each update by a header
or a governance proposal. The latest client state is also maintained in the store.

