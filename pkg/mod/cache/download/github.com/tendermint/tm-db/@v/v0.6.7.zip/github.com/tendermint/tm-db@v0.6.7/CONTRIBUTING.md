# Contributing

Thank you for your interest in contributing to tm-db!
This repository follows the [contribution guidelines] of tendermint and the corresponding [coding repo].
Please take a look if you are not already familiar with those.

[contribution guidelines]: https://github.com/tendermint/tendermint/blob/master/CONTRIBUTING.md
[coding repo]: https://github.com/tendermint/coding
