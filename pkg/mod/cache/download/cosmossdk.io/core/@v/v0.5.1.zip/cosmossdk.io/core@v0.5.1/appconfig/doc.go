// Package appconfig defines functionality for loading declarative Cosmos SDK
// app configurations.
package appconfig
