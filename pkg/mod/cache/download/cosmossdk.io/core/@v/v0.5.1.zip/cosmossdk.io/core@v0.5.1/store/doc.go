// Package store provides a basic API for modules to interact with kv-stores
// independently of any implementation of that functionality.
package store
